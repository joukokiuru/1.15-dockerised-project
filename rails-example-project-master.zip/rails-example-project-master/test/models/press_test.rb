require 'test_helper'

class PressTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
