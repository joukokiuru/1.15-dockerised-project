class Press < ApplicationRecord
end
